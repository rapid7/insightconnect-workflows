# Description

Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Egestas maecenas pharetra convallis posuere morbi. Penatibus et magnis dis parturient montes nascetur ridiculus mus mauris. Varius duis at consectetur lorem donec massa sapien faucibus et. Ut enim blandit volutpat maecenas.


# Key Features

* Euismod quis viverra nibh cras
* Viverra nibh cras pulvinar mattis
* Quam vulputate dignissim suspendisse in

# Requirements

* Orci phasellus egestas
* Porttitor eget dolor

# Documentation

## Setup

Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. At imperdiet dui accumsan sit. Vivamus arcu felis bibendum ut tristique et egestas quis.

Accumsan tortor posuere ac ut consequat semper viverra nam libero. Sodales ut etiam sit amet nisl purus in mollis nunc.

## Technical Details

Plugins utilized by workflow:

|Plugin|Version|Count|
|----|----|--------|
|Plugin 1|1.0.0|1|
|Plugin 2|1.0.0|1|
|Plugin 3|1.0.1|1|

## Troubleshooting

_There is no troubleshooting information at this time_

# Version History

* 1.0.0 - Initial workflow

# Links

## References

* [Rapid7 Vulnerability Database](https://www.rapid7.com/db)
* [Slack](https://slack.com)
